import java.util.LinkedList;
import java.util.Queue;

public class Dijkstra {

	//queue
	Queue<Cave> queue = new LinkedList<Cave>();
	
	//current cave 
	Cave currentCave;
	
	@SuppressWarnings("unchecked")
	public void Compute(LinkedList<Cave> caves, Cave source, Cave destination){
	    
		//First cave distance is set to 0
	    source.setDistance(0);
	    
	    //Each cave that is not the first cave is set to max value. Every cave is added to the queue
		for(Cave cave : caves){
			if(cave != source){
				cave.setDistance(Integer.MAX_VALUE);
			}
			queue.add(cave);
		}
		
		//Check that the queue is not empty
		while(!(queue.isEmpty())){ 
			
		    //current cave is set to the cave that has the lowest distance within the queue
			double minValue = Double.MAX_VALUE;
			for(Cave cave : queue){
				double value = cave.getDistance();
				if(value < minValue){
					minValue = value;
				    currentCave = cave; 
				}
			}
			
			//The current cave is removed from the queue
			queue.remove(currentCave); 
			
			//While loop terminated if current cave is equal to the final cave 
			if(currentCave == destination){
			    break;
			}
		      
		    
			for(Cave caveNeighbour : queue){ 
				//Check if current cave and the next cave is connected
				if(ReadCaverns.connected(currentCave.getNodeNumber(), caveNeighbour.getNodeNumber())){
					//distance between current cave and neighbour cave 
					double minDistance = (currentCave.getDistance() + Math.hypot(currentCave.getX()-caveNeighbour.getX(), currentCave.getY()-caveNeighbour.getY()));
					//checks if the minimum distance is less than the neighbour cave distance 
					if(minDistance < caveNeighbour.getDistance()){
						//cave neighbour distance is set to the minimum distance 
						caveNeighbour.setDistance(minDistance);
						//cave neighbour is set to current cave 
						caveNeighbour.setPredecessor(currentCave);
					}
				}
			}	
		}	
	}
}

