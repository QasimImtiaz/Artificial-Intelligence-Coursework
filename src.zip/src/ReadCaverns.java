
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Deque;
import java.util.LinkedList;
import javax.swing.JFrame;
import javax.swing.JTextField;

import org.miv.mbox.MBoxBase.Message;

public class ReadCaverns {
	
	//Checked if current cave and neighbour cave is connected or not 
	public static Boolean connected(int cave1, int cave2) {
		return Connected[cave1 - 1][cave2 - 1];
	}
	

	//boolean 2D array
	private static boolean[][] Connected;
	
	public static void main(String[] args) throws IOException {
     
		
		BufferedReader br = new BufferedReader(new FileReader("input.cav"));

		// Read the line of comma separated text from the file
		String buffer = br.readLine();
		System.out.println("Raw data : " + buffer);
		
		//close buffered reader
		br.close();

		// Convert the data to an array
		String[] data = buffer.split(",");

		// Now extract data from the array - note that we need to convert from
		// String to int as we go
		int noOfCaves = Integer.parseInt(data[0]);
		
		//print our number of caves
		System.out.println("There are " + noOfCaves + " caves.");

		//Linked list of caves 
		LinkedList<Cave> caves = new LinkedList<Cave>();

		
		Connected = new boolean[noOfCaves][noOfCaves];

		//Set coordinates to each cave and add cave to the caves list 
		for (int cave = 1; cave <= noOfCaves; cave++) {
			int x = Integer.parseInt(data[2 * cave - 1]);
			int y = Integer.parseInt(data[2 * cave]);
			caves.add(new Cave(x, y, cave));
		}

		// Build connectivity matrix

		// Declare the array

		// Now read in the data - the starting point in the array is after the
		// coordinates

		//When two caves are connected o each other, the connected 2D array is set to 1
		int start = noOfCaves * 2 + 1;
		for (int i = 0; start + i < data.length; i++) {
		    Connected[i % noOfCaves][i / noOfCaves] = Integer.parseInt(data[start + i]) == 1;
		}


		Dijkstra dijkstra = new Dijkstra();
		LinkedList<Cave> listOfCaves = new LinkedList<Cave>();

		//Dijkstra method is computed
		dijkstra.Compute(caves, caves.getFirst(), caves.getLast());
		
		//Total distance is printed out 
		System.out.println("Total Distance is " + caves.getLast().getDistance());
		
		//Caves are pushed to the path and added to list of caves linked list from last cave to start cave 
		Deque<Cave> path = new LinkedList<>();
		Cave cave = caves.getLast();
		while (cave != null) {
		    path.push(cave);
		    listOfCaves.add(cave);
		    cave = cave.getPredecessor();  
		}
	
		//The shortest route is printed out in one go 
		for (Cave currentCave : path) {
			System.out.println("Cave number is " + currentCave.getNodeNumber() + " The coordinates is " + currentCave.getX() + "," + currentCave.getY() + " current distance is "
			+ currentCave.getDistance());
		}
		
		class MyKeyListener extends KeyAdapter{
			
			int i = listOfCaves.size();
			//Key pressed method
			public void keyPressed(KeyEvent evt){
				 
			     i--;
		         //Search stepped through by pressing the 'a' key to advance by one step. Each information about current state of search is displayed at each step. 
			     if(i > 0 && evt.getKeyChar() == 'a'){
			    	 System.out.println("The cave number is " + listOfCaves.get(i).getNodeNumber() + " The coordinates is " + listOfCaves.get(i).getX() + "," + 
			         listOfCaves.get(i).getY()  + " The current distance is " + listOfCaves.get(i).getDistance());	    
			     }
			     else if(i == 0 && evt.getKeyChar() == 'a'){
			    	 System.out.println("The cave number is " + listOfCaves.get(i).getNodeNumber() + " The coordinates is " + listOfCaves.get(i).getX() + "," +
			         listOfCaves.get(i).getY()  + " The total length of route is " + listOfCaves.get(i).getDistance());
			     }    
			}						
		}
		
		//Text field 
		JTextField component = new JTextField();
		
		//Key listener
		component.addKeyListener(new MyKeyListener());
		
		//frame:
		JFrame f = new JFrame();
		f.add(component);
		f.setSize(300, 300);
		f.setVisible(true);
	}
}	
	
	

