
public class Cave {
	
	//integers:
    private int x; 
	private int y; 
	private int node_number;
	
	//double
	private double distance;
	
	//Cave
	private Cave predecessor;
	
	//constructor
	public Cave(int x, int y, int node) {
	    this.x = x;
	    this.y = y;
	    this.node_number = node;
	}
	
   //get and set methods:
   public int getNodeNumber(){
	   return node_number;
   }
   
   public int getX(){
	   return x;
   }
   
   public int getY(){
	   return y; 
   }
   
   public void setDistance(double distance){
	   this.distance = distance; 
   }
   
   public double getDistance(){
	   return distance; 
   }
   
   public void setPredecessor(Cave cave) {
       predecessor = cave;
   }
   
   public Cave getPredecessor() {
       return predecessor;
   }
   
   public void setNodeNumber(int nodeNumber){
	   this.node_number = nodeNumber;
   }
   
   public void setX(int x){
	   this.x = x;
   }
   
   public void setY(int y){
	   this.y = y; 
   }
}